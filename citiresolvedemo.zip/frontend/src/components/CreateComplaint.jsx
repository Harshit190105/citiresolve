import React, {useState} from 'react'
import axios from 'axios'
export default function CreateComplaint(){
  const [title,setTitle] = useState('Pothole on Main St')
  const [category,setCategory] = useState('roads')
  const [desc,setDesc] = useState('Huge pothole needs repair')
  const [lat,setLat] = useState('26.8467')
  const [lng,setLng] = useState('80.9462')

  const submit = async (e)=>{
    e.preventDefault()
    try{
      const res = await axios.post('http://localhost:8000/api/complaints/', {title, description: desc, category, lat, lng}, {withCredentials:true})
      alert('Created: ' + res.data.id)
    }catch(err){
      console.error(err)
      alert('Error: Make sure backend is running and you are authenticated (use Django admin to create a user).')
    }
  }
  return (
    <form onSubmit={submit} style={{display:'grid',gap:8,maxWidth:600}}>
      <input value={title} onChange={e=>setTitle(e.target.value)} />
      <select value={category} onChange={e=>setCategory(e.target.value)}>
        <option value="roads">Roads</option><option value="electricity">Electricity</option><option value="sanitation">Sanitation</option>
      </select>
      <textarea value={desc} onChange={e=>setDesc(e.target.value)} />
      <input value={lat} onChange={e=>setLat(e.target.value)} />
      <input value={lng} onChange={e=>setLng(e.target.value)} />
      <button type="submit">Create Complaint</button>
    </form>
  )
}
