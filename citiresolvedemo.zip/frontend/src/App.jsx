import React from 'react'
import CreateComplaint from './components/CreateComplaint'
export default function App(){
  return (<div style={{padding:20}}><h1>CitiResolve — Minimal Demo</h1><CreateComplaint/></div>)
}
