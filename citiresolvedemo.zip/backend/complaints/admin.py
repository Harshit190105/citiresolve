from django.contrib import admin
from .models import Complaint, ComplaintUpdate
admin.site.register(Complaint)
admin.site.register(ComplaintUpdate)
