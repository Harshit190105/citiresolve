from rest_framework import serializers
from .models import Complaint, ComplaintUpdate
class ComplaintUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComplaintUpdate
        fields = '__all__'
        read_only_fields = ('created_by','created_at')
class ComplaintSerializer(serializers.ModelSerializer):
    updates = ComplaintUpdateSerializer(many=True, read_only=True)
    class Meta:
        model = Complaint
        fields = '__all__'
        read_only_fields = ('created_by','created_at','status','department','assigned_to','rating')
