from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Complaint, ComplaintUpdate
from .serializers import ComplaintSerializer, ComplaintUpdateSerializer

class ComplaintViewSet(viewsets.ModelViewSet):
    queryset = Complaint.objects.all().order_by('-created_at')
    serializer_class = ComplaintSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def perform_create(self, serializer):
        instance = serializer.save(created_by=self.request.user)
        try:
            from .tasks import auto_route_complaint
            auto_route_complaint.delay(str(instance.id))
        except Exception:
            from .tasks import auto_route_complaint_sync
            auto_route_complaint_sync(str(instance.id))

    @action(detail=True, methods=['post'])
    def add_update(self, request, pk=None):
        complaint = self.get_object()
        serializer = ComplaintUpdateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(complaint=complaint, created_by=request.user)
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def rate(self, request, pk=None):
        complaint = self.get_object()
        if complaint.status not in ['resolved','closed']:
            return Response({'detail':'Only resolved complaints can be rated.'}, status=status.HTTP_400_BAD_REQUEST)
        complaint.rating = int(request.data.get('rating',0))
        complaint.rating_comment = request.data.get('comment','')
        complaint.save()
        return Response({'ok':True})
