from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ComplaintUpdate
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from .serializers import ComplaintUpdateSerializer

@receiver(post_save, sender=ComplaintUpdate)
def publish_update(sender, instance, created, **kwargs):
    if not created:
        return
    channel_layer = get_channel_layer()
    group_name = f"complaint_{instance.complaint.id}"
    data = ComplaintUpdateSerializer(instance).data
    async_to_sync(channel_layer.group_send)(group_name, {'type':'send_update', 'data': data})
