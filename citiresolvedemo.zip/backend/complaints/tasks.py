from celery import shared_task
from .models import Complaint, ComplaintUpdate
from departments.models import Department, StaffProfile

def auto_route_complaint_sync(complaint_id):
    try:
        complaint = Complaint.objects.get(pk=complaint_id)
    except Complaint.DoesNotExist:
        return
    dept_map = {'roads':'roads','electricity':'electricity','sanitation':'sanitation'}
    dept_code = dept_map.get(complaint.category)
    department = Department.objects.filter(code=dept_code).first()
    complaint.department = department
    staff = None
    if department:
        staff = StaffProfile.objects.filter(department=department, is_available=True).first()
    if staff:
        complaint.assigned_to = staff
        complaint.status = 'assigned'
        complaint.save()
        ComplaintUpdate.objects.create(complaint=complaint, status='assigned', message=f'Auto-assigned to {staff.user.username}')
    else:
        complaint.status = 'submitted'
        complaint.save()

@shared_task
def auto_route_complaint(complaint_id):
    auto_route_complaint_sync(complaint_id)
