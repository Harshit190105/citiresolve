from django.db import models
from accounts.models import User
from departments.models import Department, StaffProfile
import uuid
class Complaint(models.Model):
    CATEGORY_CHOICES = [('roads','Roads'),('electricity','Electricity'),('sanitation','Sanitation'),]
    STATUS_CHOICES = [('submitted','Submitted'),('assigned','Assigned'),('in_progress','In Progress'),('on_the_way','On the way'),('resolved','Resolved'),('closed','Closed'),('rejected','Rejected'),]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.CharField(max_length=30, choices=CATEGORY_CHOICES)
    address = models.CharField(max_length=300, blank=True)
    lat = models.FloatField(null=True, blank=True)
    lng = models.FloatField(null=True, blank=True)
    photo = models.ImageField(upload_to='complaint_photos/', blank=True, null=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='submitted')
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True)
    assigned_to = models.ForeignKey(StaffProfile, on_delete=models.SET_NULL, null=True, blank=True)
    priority = models.IntegerField(default=3)
    rating = models.IntegerField(null=True, blank=True)
    rating_comment = models.TextField(blank=True, null=True)

class ComplaintUpdate(models.Model):
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='updates')
    status = models.CharField(max_length=30, choices=Complaint.STATUS_CHOICES)
    message = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    lat = models.FloatField(null=True, blank=True)
    lng = models.FloatField(null=True, blank=True)
