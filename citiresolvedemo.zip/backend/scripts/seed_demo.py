from departments.models import Department, StaffProfile
from accounts.models import User
dept_codes = [('Roads','roads'),('Electricity','electricity'),('Sanitation','sanitation')]
for name,code in dept_codes:
    Department.objects.get_or_create(code=code, defaults={'name':name})
u, created = User.objects.get_or_create(username='tech1')
if created:
    u.set_password('pass123'); u.role='staff'; u.save()
StaffProfile.objects.get_or_create(user=u, department=Department.objects.get(code='roads'), defaults={'is_available':True, 'lat':26.85, 'lng':80.95})
print('Seed complete')
